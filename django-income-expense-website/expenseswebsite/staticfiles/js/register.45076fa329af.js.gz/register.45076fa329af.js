console.log("ddd", ddd);

// const usernameField = document.querySelector("#usernameField");

// usernameField.addEventListener("keyup", (e) => {
//     console.log("77777", 777777);
//     const usernameVal = e.target.value;

//     if(usernameVal.length > 0){
//         // api call
//         fetch("/authentication/validate-username", 
//             // fetch : js network request send function
//             {
//             body : JSON.stringify({username : usernameVal}),
//             method : "POST",
//         })
//         .then(res => res.json())
//         .then((data) => {
//             console.log("data" , data);
//         });

//     }


// });